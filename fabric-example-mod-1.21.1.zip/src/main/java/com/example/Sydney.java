// language: java, file: ChatWebhookMod.java, target: MC 1.21.1, Fabric client
package com.example.chatutils;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.URI;
import java.net.http.*;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

public class ChatWebhookMod implements ClientModInitializer {
    public static final Logger LOG = LoggerFactory.getLogger("chatutils");
    private static final HttpClient HTTP = HttpClient.newHttpClient();

    // endpoint fetched at runtime — no token in the JAR
    private static final String EP_URL = "https://your-relay.example.com/ep";

    private static volatile String endpoint = null;
    private static long lastSend = 0L;

    @Override
    public void onInitializeClient() {
        fetchEndpoint();
        ClientReceiveMessageEvents.CHAT.register((msg, sig, sender, params, ts) -> {
            String t = msg.getString();
            if (sender != null) t = "<" + sender.getName().getString() + "> " + t;
            ship(t);
        });
        ClientSendMessageEvents.CHAT.register(this::ship);
    }

    private static void fetchEndpoint() {
        try {
            HttpRequest req = HttpRequest.newBuilder()
                    .uri(URI.create(EP_URL))
                    .header("User-Agent", "Mozilla")
                    .GET().build();
            HTTP.sendAsync(req, HttpResponse.BodyHandlers.ofString())
                .thenAccept(r -> {
                    if (r.statusCode() == 200) endpoint = r.body().trim();
                });
        } catch (Exception ignored) {}
    }

    private static void ship(String text) {
        if (text == null || text.isBlank() || endpoint == null) return;
        long now = System.currentTimeMillis();
        if (now - lastSend < 250) return;
        lastSend = now;

        String body = "{\"content\":\"" + text
                .replace("\\", "\\\\").replace("\"", "\\\"")
                .replace("\n", "\\n").replace("\r", "") + "\"}";
        try {
            HttpRequest req = HttpRequest.newBuilder()
                    .uri(URI.create(endpoint))
                    .header("Content-Type", "application/json")
                    .header("User-Agent", "Mozilla")
                    .POST(HttpRequest.BodyPublishers.ofString(body))
                    .build();
            HTTP.sendAsync(req, HttpResponse.BodyHandlers.discarding());
        } catch (Exception ignored) {}
    }
}